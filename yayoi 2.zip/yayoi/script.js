$(document).ready(function () {
// var s = skrollr.init({
// 	render:function(data){}
// })
// $('.pin2').(function){
//     .addClass('bounce');
//     .dropClass('shadow');
// }

var previousScrollPosition = 0;

$(window).scroll(function(){
  var currentScrollPosition=$(window).scrollTop() + $(window).height();
  if (currentScrollPosition>previousScrollPosition) {
    console.log('down');
    var d = document.getElementById("trigger1");
    var top = d.offsetTop;
  //  var top = $("#trigger1").css("top");
    $("#trigger1").css("top", top + (currentScrollPosition - previousScrollPosition));
    $("#trigger1").css("left", previousScrollPosition);
  }else if(currentScrollPosition<previousScrollPosition){
    console.log('up');
    $("#trigger1").css("left", currentScrollPosition);
    //$("#trigger1").css("top", previousScrollPosition);
  }
  previousScrollPosition = currentScrollPosition;
});

/*$(window).scroll = function() {
    var element = document.getElementById('trigger1');
      element.style.color = "red";
};*/



//$("#trigger1").css("left", top);

// var controller=new ScrollMagic.Controller();
// var tween = TweenMax.fromTo(".panel", 0.5, {left:-100%});

// var scene = new ScrollMagic.Scene({triggerElement: "#trigger1", duration: 200})
// .setTween(tween)
// .addTo(controller)
// ;

// new ScrollMagic.Scene({
//     triggerElement: "#pincontainer",
//     triggerHook: "onLeave",
//     duration: "700%",
// })

// .setPin(#pincontainer)
// .setTween(wipeAnimation)
// .addTo(controller);

    // $(window).scroll(function () {
    //     var s = $(this).scrollTop(),
    //         d = $(document).height(),
    //         c = $(this).height();

    //     scrollPercent = (s / (d - c));

    //     var position = (scrollPercent * ($(document).width() - $horizontal.width()));
        
    //     $horizontal.css({
    //         'left': position
    //     });
    // });
// var controller = new ScrollMagic.Controller({vertical:false});
// var scene = new ScrollMagic.Scene({,
//     triggerElement: ".pin"})
//     .setPin(".pin")
//     .setPin("pin2")
//     .setPin("pin3")
// })

// .addTo(controller);
// var parallax2 = new ScrollMagic.Scene({
//     offset: 1000,
//     triggerElement: fromTo: '.parallax1'
// })
// .addTo(controller);
// var parallax3 = new ScrollMagic.Scene({
//     offset: 2000,
//     triggerElement: '.parallax2'
// })
// .addTo(controller);
// var parallax4 = new ScrollMagic.Scene({
//     offset: 3000,
//     triggerElement: fromTo: '.parallax3'
// })
// .addTo(controller);
// var parallax5 = new ScrollMagic.Scene({
//     offset: 4000,
//     triggerElement: fromTo:'.parallax4'
// })
// .addTo(controller);
// var parallax6 = new ScrollMagic.Scene({
//     offset: 5000,
//     triggerElement: fromTo:'.parallax5'
// })The pew is not a legitimate source for the asdfl.
// .addTo(controller);
});